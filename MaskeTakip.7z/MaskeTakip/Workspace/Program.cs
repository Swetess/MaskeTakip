﻿

//DRY Uyumsuz
using Business.Concrete;
using Entities.Concrete;

internal class Program
{
    private static void Main(string[] args)
    {
        static void Degiskenler()
        {
            //DRY prensibi çiğnenmeden kullanım
            double tutar = 100000;//Bu değer db den gelmektedir.
            int sayi = 100;
            bool girisYapmisMi = false;
            Vatandas vatandas = new Vatandas();


            Console.WriteLine(tutar * 1.18);
            Console.WriteLine(tutar * 1.18);

            Console.ReadLine();
        }


        static void SelamVer(string isim = "isimsiz")
        {
            Console.WriteLine($"Selam {isim}");
        }

        static int Topla(int sayi1 = 5, int sayi2 = 10)
        {
            int sonuc = sayi1 + sayi2;
            Console.WriteLine($"Toplam : {sonuc}");
            return sonuc;

        }
        //Degiskenler()
        Vatandas vatandas = new Vatandas();

        SelamVer("Oğuzhan");
        SelamVer("Doğukan");
        SelamVer();
        int toplam = Topla(50);

        //Diziler-Referans Tipler
        string ogrenci1 = "Engin";
        string ogrenci2 = "Melike";
        string ogrenci3 = "Mahmut";
        string[] ogrenciler = new string[3];
        ogrenciler[0] = "Engin";
        ogrenciler[1] = "Melike";
        ogrenciler[2] = "Mahmut";
        ogrenciler = new string[4];
        ogrenciler[3] = "Turgay";
        for (int i = 0; i < ogrenciler.Length; i++)
        {
            Console.WriteLine(ogrenciler[i]);
        }
        string[] sehirler1 = { "İstanbul", "Ankara", "Konya" };
        string[] sehirler2 = { "Bursa", "Kastamonu", "Diyarbakır" };
        sehirler1 = sehirler2;
        sehirler1[1] = "Antalya";
        //Generic collections varken günlük hayatta klasik arraylari "[]" kullanmıyoruz.
        List<string> yenisehirler = new List<string>() { "İstanbul 1", "Ankara 1", "Konya 1" };
        yenisehirler.Add("Adana 1");



        Person person1 = new Person();
        person1.FirstName = "Oğuzhan";
        person1.LastName = "KORKMAZ";
        person1.DateOfBirthYear = 2002;
        person1.NationalIdentity = 56545644546;
        Person person2 = new Person();
        person2.FirstName = "Murat";

        foreach (string sehir in yenisehirler)
        {
            Console.WriteLine(sehir);
        }

        PttManager pttManager = new PttManager(new PersonManager());
        pttManager.GiveMask(person1);




        Console.ReadLine();
    }
}

public class Vatandas
{
    public string Ad { get; set; }
    public string Soyad { get; set; }
    public int DogumYili { get; set;}
    public long TcNo { get;set;}
    
}
